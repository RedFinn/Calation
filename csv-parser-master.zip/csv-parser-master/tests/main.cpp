#define CATCH_CONFIG_MAIN

// For Catch + MSVC
#define _SILENCE_CXX17_UNCAUGHT_EXCEPTION_DEPRECATION_WARNING

#include <catch2/catch_all.hpp>